plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// 최신 대회 데이터 주소 (GitHub Actions가 자동으로 넣어줍니다)
val dataUrl: String = (project.findProperty("dataUrl") as String?) ?: ""

android {
    namespace = "kr.yangsan.race"
    compileSdk = 34

    defaultConfig {
        applicationId = "kr.yangsan.race"
        minSdk = 26
        targetSdk = 34
        versionCode = (project.findProperty("versionCode") as String?)?.toInt() ?: 1
        versionName = "1.0." + ((project.findProperty("versionCode") as String?) ?: "1")
        buildConfigField("String", "DATA_URL", "\"$dataUrl\"")
    }

    signingConfigs {
        create("club") {
            // 동호회 배포용 서명 키 (업데이트 설치가 가능하도록 항상 같은 키를 사용)
            storeFile = file(System.getenv("KEYSTORE_FILE") ?: "club.keystore")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "yangsan2027"
            keyAlias = System.getenv("KEY_ALIAS") ?: "yangsan"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "yangsan2027"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("club")
        }
        debug {
            signingConfig = signingConfigs.getByName("club")
        }
    }
    buildFeatures { buildConfig = true }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
