package kr.yangsan.race

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

/**
 * 하루 두 번 백그라운드에서 실행됩니다.
 * 1) 온라인 최신 대회 데이터를 내려받고  2) 관심 대회의 접수·대회·훈련 시작 일정을 확인해 알림을 보냅니다.
 * 같은 알림은 한 번만 보냅니다.
 */
class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    companion object {
        const val PREFS = "race"
        private const val CHANNEL = "race_alerts"
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<ReminderWorker>(12, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("race-reminder", ExistingPeriodicWorkPolicy.KEEP, req)
        }
        fun runNow(ctx: Context) {
            WorkManager.getInstance(ctx).enqueue(OneTimeWorkRequestBuilder<ReminderWorker>().build())
        }
    }

    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(PREFS, 0)
        val favs = try { JSONArray(prefs.getString("favs", "[]")).let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } } catch (e: Exception) { emptySet() }
        if (favs.isEmpty()) return Result.success()

        // 화면에서 저장한 관심 대회 정보 + 훈련 기간
        val cached = try { JSONObject(prefs.getString("events", "{}")) } catch (e: Exception) { JSONObject() }
        val planWeeks = cached.optJSONObject("planWeeks") ?: JSONObject()
        val events = mutableMapOf<String, JSONObject>()
        cached.optJSONArray("events")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { events[it.getString("id")] = it } }

        // 온라인 최신 데이터로 덮어쓰기 (실패하면 저장된 정보 사용)
        if (BuildConfig.DATA_URL.isNotEmpty()) {
            try {
                val conn = URL(BuildConfig.DATA_URL + "?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000; conn.readTimeout = 20000
                if (conn.responseCode == 200) {
                    val arr = JSONObject(conn.inputStream.bufferedReader().readText()).getJSONArray("events")
                    for (i in 0 until arr.length()) arr.getJSONObject(i).let { if (it.getString("id") in favs) events[it.getString("id")] = it }
                }
                conn.disconnect()
            } catch (e: Exception) { /* 오프라인 */ }
        }

        val today = LocalDate.now(ZoneId.of("Asia/Seoul"))
        val sent = prefs.getStringSet("sent", emptySet())!!.toMutableSet()
        val alerts = mutableListOf<Triple<String, String, String>>() // key, title, body

        fun days(s: String?): Long? = try { if (s.isNullOrBlank()) null else ChronoUnit.DAYS.between(today, LocalDate.parse(s)) } catch (e: Exception) { null }

        for ((id, e) in events) {
            if (id !in favs) continue
            val name = e.optString("name")
            val rs = days(e.optString("regStart")); val re = days(e.optString("regEnd")); val rd = days(e.optString("date"))
            if (rs != null && rs in 0..7) alerts += Triple("$id:rs", name, if (rs == 0L) "오늘 접수가 시작돼요" else "접수 시작 ${rs}일 전")
            if (re != null && rs != null && rs < 0 && re in 0..5) alerts += Triple("$id:re", name, if (re == 0L) "오늘 접수 마감!" else "접수 마감 ${re}일 전")
            if (rd != null) {
                if (rd in 0..7) alerts += Triple("$id:d7", name, if (rd == 0L) "오늘이 대회날이에요. 좋은 레이스 되세요!" else "대회 ${rd}일 전 · 테이퍼와 장비 점검")
                else if (rd in 8..30) alerts += Triple("$id:d30", name, "대회 ${rd}일 전 · 테이퍼 기간이 다가와요")
                val w = planWeeks.optInt(e.optString("plan"), 0)
                if (w > 0) { val ps = rd - w * 7; if (ps in 0..7) alerts += Triple("$id:plan", name, if (ps == 0L) "오늘부터 훈련 시작!" else "훈련 시작 ${ps}일 전 (${w}주 플랜)") }
            }
        }

        val nm = NotificationManagerCompat.from(applicationContext)
        if (!nm.areNotificationsEnabled()) return Result.success()
        createChannel()
        val open = PendingIntent.getActivity(applicationContext, 0,
            Intent(applicationContext, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        for ((key, title, body) in alerts) {
            if (key in sent) continue
            val n = NotificationCompat.Builder(applicationContext, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_flag)
                .setContentTitle("양산철인 · $title")
                .setContentText(body)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            try { nm.notify(key.hashCode(), n); sent += key } catch (e: SecurityException) { }
        }
        prefs.edit().putStringSet("sent", sent).apply()
        return Result.success()
    }

    private fun createChannel() {
        val mgr = applicationContext.getSystemService(NotificationManager::class.java)
        if (mgr.getNotificationChannel(CHANNEL) == null) {
            mgr.createNotificationChannel(NotificationChannel(CHANNEL,
                applicationContext.getString(R.string.channel_name), NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = applicationContext.getString(R.string.channel_desc)
            })
        }
    }
}
