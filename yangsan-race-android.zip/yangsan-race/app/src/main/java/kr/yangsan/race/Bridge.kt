package kr.yangsan.race

import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat

/** 웹 화면(JavaScript)과 안드로이드 앱을 연결합니다. JS에서 window.Android 로 호출합니다. */
class Bridge(private val activity: MainActivity) {
    private val prefs = activity.getSharedPreferences(ReminderWorker.PREFS, 0)

    @JavascriptInterface
    fun setFavorites(json: String) { prefs.edit().putString("favs", json).apply() }

    @JavascriptInterface
    fun cacheEvents(json: String) { prefs.edit().putString("events", json).apply() }

    @JavascriptInterface
    fun notificationsEnabled(): Boolean = NotificationManagerCompat.from(activity).areNotificationsEnabled()

    @JavascriptInterface
    fun requestNotificationPermission() { activity.runOnUiThread { activity.requestNotif() } }

    @JavascriptInterface
    fun dataUrl(): String = BuildConfig.DATA_URL
}
