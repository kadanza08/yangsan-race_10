# 양산철인 레이스 캘린더 - Claude 작업 안내

이 폴더는 안드로이드 앱(WebView) 프로젝트입니다. 사용자가 "APK로 빌드해줘"라고 하면 아래 순서로 진행하세요.

## 목표
`app/build/outputs/apk/release/app-release.apk` 를 만들고, 프로젝트 최상위에 `yangsan-race.apk` 로 복사한 뒤 위치를 알려 주세요.

## 빌드 순서 (Windows 기준, macOS/Linux도 동일한 흐름)
1. JDK 17 확인: `java -version`. 없으면 Temurin JDK 17을 설치합니다 (winget: `winget install EclipseAdoptium.Temurin.17.JDK`).
2. Android SDK 준비
   - Android Studio가 있으면 그 SDK를 사용합니다 (보통 `%LOCALAPPDATA%\Android\Sdk`).
   - 없으면 Android command-line tools를 내려받아 `sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"` 를 설치하고 라이선스에 동의합니다.
   - 프로젝트 최상위에 `local.properties` 를 만들고 `sdk.dir=SDK경로` 를 적습니다 (Windows 경로는 `\\` 로 이스케이프).
3. Gradle 8.7 준비: 이 프로젝트에는 gradle wrapper가 없습니다. Gradle 8.7을 설치하거나, 설치된 gradle로 `gradle wrapper --gradle-version 8.7` 을 실행해 wrapper를 만든 뒤 `gradlew` 를 사용합니다.
4. 빌드: `gradle :app:assembleRelease` (또는 `.\gradlew.bat :app:assembleRelease`)
   - 서명 키는 `app/club.keystore` 가 이미 들어 있습니다 (비밀번호는 app/build.gradle.kts 참고). 지우지 마세요. 같은 키여야 덮어쓰기 업데이트가 됩니다.
5. 결과 APK를 `yangsan-race.apk` 로 복사하고, 휴대폰으로 옮기는 방법(USB, 카카오톡 나에게 보내기, 구글 드라이브)을 안내합니다.

## 참고
- 앱 화면은 `app/src/main/assets/index.html` 하나에 들어 있습니다. 대회 데이터도 이 안에 포함되어 있어 인터넷 없이도 동작합니다.
- `app/src/main/assets/config.js` 의 `dataUrl` 에 data/data.json 을 올린 공개 주소를 넣으면, 앱이 실행될 때마다 그 주소에서 최신 데이터를 받아옵니다. 비어 있으면 앱에 포함된 데이터를 사용합니다.
- 빌드 오류가 나면 오류 메시지를 읽고 원인을 고친 뒤 다시 빌드하세요 (예: SDK 경로, 라이선스 미동의, JDK 버전).
