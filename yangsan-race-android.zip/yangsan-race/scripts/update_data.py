"""
양산철인 레이스 캘린더 - 대회 정보 자동 업데이트

매일 GitHub Actions에서 실행됩니다.
1) 앞으로 열릴 대회(그리고 최근 끝난 대회)를 몇 개씩 묶어 Claude에게 웹 검색으로 공식 발표를 확인하게 하고
   날짜·접수·참가비·공식 홈페이지 등 바뀐 항목만 반영합니다.
2) 끝난 대회 중 다음 해 일정이 발표된 대회는 새 대회로 추가합니다.
3) 철인3종·마라톤·자전거 최신 소식을 다시 모읍니다.
결과는 data/data.json 에 저장되고, 앱은 실행할 때마다 이 파일을 내려받습니다.
"""
import json, os, re, sys, datetime as dt
from zoneinfo import ZoneInfo
import anthropic

PATH = os.path.join(os.path.dirname(__file__), "..", "data", "data.json")
MODEL = os.environ.get("UPDATE_MODEL", "claude-sonnet-5-5")
TODAY = dt.datetime.now(ZoneInfo("Asia/Seoul")).date()
ALLOWED = {"date", "dateStatus", "dateText", "regStart", "regEnd", "regText", "price", "people",
           "venue", "url", "urlLabel", "dist", "course", "summary", "note", "host"}
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

if not os.environ.get("ANTHROPIC_API_KEY"):
    print("ANTHROPIC_API_KEY 가 없어서 업데이트를 건너뜁니다. 저장소 Settings > Secrets 에 등록하세요.")
    sys.exit(0)

client = anthropic.Anthropic()
TOOLS = [{"type": "web_search_20250305", "name": "web_search", "max_uses": 8}]


def ask(prompt: str) -> str:
    """웹 검색을 쓰는 Claude 호출. 긴 검색으로 멈추면(pause_turn) 이어서 진행."""
    messages = [{"role": "user", "content": prompt}]
    for _ in range(4):
        r = client.messages.create(model=MODEL, max_tokens=8000, tools=TOOLS, messages=messages)
        if r.stop_reason == "pause_turn":
            messages = [messages[0], {"role": "assistant", "content": r.content}]
            continue
        return "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
    return ""


def parse_json(text: str):
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:
        return None


def clean_fields(d: dict) -> dict:
    out = {}
    for k, v in d.items():
        if k not in ALLOWED or v in (None, ""):
            continue
        if k in ("date", "regStart", "regEnd") and not DATE_RE.match(str(v)):
            continue
        if k == "dateStatus" and v not in ("확정", "예상"):
            continue
        if k == "url" and not str(v).startswith("http"):
            continue
        out[k] = v
    return out


def main():
    data = json.load(open(PATH, encoding="utf-8"))
    events = {e["id"]: e for e in data["events"]}
    changed = 0

    # 앞으로 열릴 대회 + 최근 60일 안에 끝난 대회(다음 해 일정 확인용)
    targets = [e for e in events.values()
               if e.get("date") and dt.date.fromisoformat(e["date"]) >= TODAY - dt.timedelta(days=60)]
    targets.sort(key=lambda e: (e.get("dateStatus") == "확정", e["date"]))  # 예상 일정부터 우선 확인

    for i in range(0, len(targets), 6):
        chunk = [{k: e.get(k) for k in ("id", "name", "cat", "date", "dateStatus", "region", "dist",
                                        "regStart", "regEnd", "regText", "price", "url")} for e in targets[i:i + 6]]
        prompt = f"""오늘은 {TODAY.isoformat()} (한국시간)입니다. 아래는 한국 철인3종·마라톤·자전거 대회 목록입니다.
각 대회에 대해 웹 검색으로 '가장 최근 공식 발표'(대회 홈페이지, 협회, 지자체, 접수 사이트, 신뢰할 수 있는 언론)를 확인하세요.

규칙:
- 공식 발표로 확인된 사실만 반영합니다. 추측이면 바꾸지 마세요.
- date가 확정 발표되면 dateStatus를 "확정"으로, 아직이면 그대로 둡니다.
- 접수 기간이 발표되면 regStart/regEnd(YYYY-MM-DD)와 regText(한 줄 설명)를 넣으세요.
- 참가비, 공식 홈페이지 url, 장소가 확인되면 넣으세요.
- 날짜가 이미 지난 대회는 바꾸지 말고, 다음 회차 일정이 발표되었거나 매년 열리는 대회라면 "next"에 다음 회차를 넣으세요
  (발표 전이면 지난 회차와 같은 시기의 같은 요일로 추정하고 dateStatus "예상").
- 문장은 짧은 한국어로, 출처 문장을 그대로 베끼지 말고 직접 요약하세요.

대회 목록(JSON):
{json.dumps(chunk, ensure_ascii=False)}

다른 설명 없이 아래 JSON 하나만 출력하세요:
{{"updates":[{{"id":"대회id","fields":{{"date":"YYYY-MM-DD","dateStatus":"확정",...}},"source":"확인한 출처 URL"}}],
  "next":[{{"from":"지난 대회id","fields":{{"name":"...","date":"YYYY-MM-DD","dateStatus":"예상 또는 확정",...}}}}]}}
바뀐 것이 없으면 {{"updates":[],"next":[]}}"""
        try:
            res = parse_json(ask(prompt)) or {}
        except Exception as ex:
            print("검색 실패:", ex)
            continue
        for u in res.get("updates", []):
            e = events.get(u.get("id"))
            f = clean_fields(u.get("fields", {}))
            if not e or not f:
                continue
            diff = {k: v for k, v in f.items() if e.get(k) != v}
            if diff:
                e.update(diff)
                if diff.get("dateStatus") == "확정":
                    e["dateText"] = ""
                    e["predicted"] = False
                e["updatedAt"] = TODAY.isoformat()
                changed += 1
                print("갱신", e["id"], diff)
        for n in res.get("next", []):
            base = events.get(n.get("from"))
            f = clean_fields(n.get("fields", {}))
            if not base or "date" not in f:
                continue
            year = f["date"][:4]
            new_id = re.sub(r"-\d{2,4}$", "", base["id"]) + "-" + year
            if new_id in events or any(x.get("name") == f.get("name", base["name"]) and x.get("date", "")[:4] == year for x in events.values()):
                continue
            new = {**base, **f, "id": new_id, "updatedAt": TODAY.isoformat()}
            new.setdefault("dateStatus", "예상")
            new["prev"] = f"{base['date'].replace('-', '.')} 개최"
            for k in ("regStart", "regEnd"):
                if k not in f:
                    new.pop(k, None)
            if "regText" not in f:
                new["regText"] = f"{year} 접수 공지 전"
            events[new_id] = new
            changed += 1
            print("다음 회차 추가", new_id)

    # 최신 소식
    try:
        res = parse_json(ask(f"""오늘은 {TODAY.isoformat()}입니다. 최근 30일 안에 나온 한국 철인3종(아이언맨 포함)·마라톤·자전거(그란폰도 등)
대회 관련 뉴스나 공식 공지를 웹 검색으로 찾아 10개를 골라 주세요. 동호인에게 유용한 것(대회 일정·접수 공지·결과·안전 이슈) 위주로,
경남 양산·부산 등 영남권 소식이 있으면 포함하세요. 요약은 출처 문장을 베끼지 말고 직접 2문장 이내 한국어로 쓰세요.
다른 설명 없이 JSON만: {{"news":[{{"cat":"tri|run|bike","date":"YYYY-MM-DD","title":"...","source":"매체명","url":"검색 결과에 나온 실제 URL","summary":"..."}}]}}""")) or {}
        items = [n for n in res.get("news", []) if str(n.get("url", "")).startswith("http") and n.get("cat") in ("tri", "run", "bike")]
        if len(items) >= 3:
            for i, n in enumerate(items):
                n["id"] = f"n{TODAY.strftime('%y%m%d')}{i}"
                n["updatedAt"] = TODAY.isoformat()
            keep = [n for n in data.get("news", []) if n.get("date", "") >= (TODAY - dt.timedelta(days=60)).isoformat()]
            urls = {n["url"] for n in items}
            data["news"] = (items + [n for n in keep if n["url"] not in urls])[:20]
            changed += 1
    except Exception as ex:
        print("소식 수집 실패:", ex)

    data["events"] = sorted(events.values(), key=lambda e: e.get("date") or "9999")
    data["asOf"] = TODAY.isoformat()   # 오늘 확인했다는 표시 (변경이 없어도 갱신)
    json.dump(data, open(PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"완료: {changed}건 변경, 기준일 {data['asOf']}")


if __name__ == "__main__":
    main()
